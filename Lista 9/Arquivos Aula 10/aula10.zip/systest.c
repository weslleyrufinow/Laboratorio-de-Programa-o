#include <stdio.h>
#include <stdlib.h>

int main(void){
    puts("Pressione Enter para ver uma lista de arquivos: ");
    getchar();
    system("dir");
    return (0);
}